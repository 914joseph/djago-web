from django.db import models

class User(models.Model):
    id = models.AutoField(primary_key=True)
    username = models.TextField(max_length=30,null=True,blank=True)
    first_name = models.TextField(max_length=30,null=True,blank=True)
    last_name = models.TextField(max_length=30,null=True,blank=True)

class Ufs(models.Model):
    id_uf = models.AutoField(primary_key=True)
    nome_uf = models.TextField(max_length=30)
    sigla_uf = models.TextField(max_length=2)

class Cidades(models.Model):
    id_cidade = models.AutoField(primary_key=True)
    nome_cidade = models.TextField(max_length=50)
    id_uf = models.ForeignKey(Ufs,on_delete=models.CASCADE)

class Enderecos(models.Model):
    id_endereco = models.AutoField(primary_key=True)
    id_cidade = models.ForeignKey(Cidades,on_delete=models.CASCADE)
    logradouro = models.TextField(max_length=150)
    numero = models.TextField(max_length=8)
    cep = models.TextField(max_length=10)
    bairro = models.TextField(max_length=80)
    complemento = models.TextField(max_length=60,null=True,blank=True)
    observacoes = models.TextField(null=True,blank=True)

class Contas(models.Model):
    id_conta = models.AutoField(primary_key=True)
    tp_conta = models.TextField(max_length=30)
    id_banco = models.IntegerField()
    banco = models.TextField(max_length=50)
    conta = models.IntegerField()
    agencia = models.IntegerField()
    operacao = models.IntegerField()

class Pessoas(models.Model):
    id_pessoa = models.AutoField(primary_key=True)
    vinculo = models.TextField(max_length=20)
    id_user = models.ForeignKey(User,on_delete=models.CASCADE)
    cpf = models.IntegerField()
    nome = models.TextField(max_length=20)
    telefone = models.TextField(max_length=16)
    email = models.TextField(max_length=50)
    id_endereco = models.ForeignKey(Enderecos,on_delete=models.CASCADE)
    id_conta = models.ForeignKey(Contas,on_delete=models.CASCADE)







class Ocorrencias(models.Model):
    id_ocorrencia = models.AutoField(primary_key=True)
    data = models.DateTimeField(auto_now_add=True)
    realizada = models.TextField(max_length=1)
    ocorrencia = models.TextField()
    id_pessoa = models.ForeignKey(Pessoas,on_delete=models.CASCADE)


